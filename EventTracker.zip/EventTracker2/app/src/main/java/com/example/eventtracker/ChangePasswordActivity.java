package com.example.eventtracker;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ChangePasswordActivity extends AppCompatActivity {

    // Database helper for accessing the SQLite database
    DatabaseHelper db;

    // UI elements for input and button
    EditText oldPassword, newPassword;
    Button btnChangePassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password); // Load the change password layout

        // Connect variables to the UI components
        db = new DatabaseHelper(this);
        oldPassword = findViewById(R.id.oldPassword);
        newPassword = findViewById(R.id.newPassword);
        btnChangePassword = findViewById(R.id.btnChangePassword);

        // Get the currently logged in user's username from shared preferences
        SharedPreferences prefs = getSharedPreferences("EventTrackerPrefs", MODE_PRIVATE);
        String username = prefs.getString("loggedInUser", null);

        // When the "Change Password" button is clicked
        btnChangePassword.setOnClickListener(v -> {

            // If no user is logged in, show an error
            if (username == null) {
                Toast.makeText(this, "Error: No user logged in", Toast.LENGTH_SHORT).show();
                return;
            }

            // Get values from the input fields
            String oldPass = oldPassword.getText().toString().trim();
            String newPass = newPassword.getText().toString().trim();

            // Make sure both fields are filled in
            if (oldPass.isEmpty() || newPass.isEmpty()) {
                Toast.makeText(this, "Enter both passwords", Toast.LENGTH_SHORT).show();
                return;
            }

            // Try to update the password in the database
            boolean updated = db.changePassword(username, newPass);

            // Show success or failure message
            if (updated) {
                Toast.makeText(this, "Password updated successfully", Toast.LENGTH_SHORT).show();
                finish(); // Close this screen
            } else {
                Toast.makeText(this, "Failed to update password", Toast.LENGTH_SHORT).show();
            }
        });
    }
}