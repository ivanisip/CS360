package com.example.eventtracker;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;

public class EventListActivity extends AppCompatActivity {

    // Layout to hold the list of events
    LinearLayout eventListContainer;

    // Button to go back to the home screen
    Button btnBackHome;

    // Database helper object
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_list);

        // Initialize database helper and UI elements
        db = new DatabaseHelper(this);
        eventListContainer = findViewById(R.id.eventListContainer);
        btnBackHome = findViewById(R.id.btnBackHome);

        // When the user taps the "Back to Home" button, go to HomeActivity
        btnBackHome.setOnClickListener(v -> {
            startActivity(new Intent(this, HomeActivity.class));
            finish(); // Closes this screen
        });

        // Load and display events from the database
        loadEvents();
    }

    // This method loads all the events from the database and displays them
    private void loadEvents() {
        eventListContainer.removeAllViews(); // Clear anything already in the list

        Cursor cursor = db.getAllItems(); // Get all event records from the database

        if (cursor != null) {
            while (cursor.moveToNext()) {
                // Get event data from the database
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_EVENT_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_EVENT_NAME));
                int value = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_EVENT_VALUE));
                String room = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_EVENT_ROOM));

                // Create a TextView to show the event details
                TextView eventView = new TextView(this);
                eventView.setText(String.format(Locale.getDefault(), "%s (%s): %d guests", name, room, value));
                eventView.setTextSize(16);
                eventView.setPadding(0, 8, 0, 8);
                eventView.setClickable(true);

                // When the user taps the event, go to EventDetailActivity and pass the data
                eventView.setOnClickListener(v -> {
                    Intent intent = new Intent(this, EventDetailActivity.class);
                    intent.putExtra("event_id", id);
                    intent.putExtra("event_name", name);
                    intent.putExtra("event_value", value);
                    intent.putExtra("event_room", room);
                    startActivity(intent);
                });

                // Add the TextView to the layout to display it on the screen
                eventListContainer.addView(eventView);
            }
            cursor.close(); // Close the cursor to free resources
        }
    }
}