package com.example.eventtracker;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class AccountInfoActivity extends AppCompatActivity {

    // Declare the database helper and text views to show user info
    DatabaseHelper db;
    TextView txtUsername, txtFullName, txtEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_info);  // Set the layout for this screen

        // Connect the database
        db = new DatabaseHelper(this);

        // Link the TextViews to the layout
        txtUsername = findViewById(R.id.txtUsername);
        txtFullName = findViewById(R.id.txtFullName);
        txtEmail = findViewById(R.id.txtEmail);

        // Get the username from saved preferences (set during login)
        SharedPreferences prefs = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        String username = prefs.getString("username", null);  // null means no user found

        // If a username is found, get the user’s data from the database
        if (username != null) {
            Cursor cursor = db.getUserByUsername(username);
            if (cursor != null && cursor.moveToFirst()) {
                // Show the user’s information in the text views
                txtUsername.setText("Username: " + username);
                txtFullName.setText("Name: " +
                        cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_USER_FIRST)) + " " +
                        cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_USER_LAST)));
                txtEmail.setText("Email: " +
                        cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_USER_EMAIL)));

                // Always close the cursor to free resources
                cursor.close();
            }
        }
    }
}