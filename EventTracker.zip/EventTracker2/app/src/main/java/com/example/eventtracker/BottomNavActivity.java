package com.example.eventtracker;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class BottomNavActivity extends AppCompatActivity {

    // Bottom navigation view for the menu at the bottom
    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bottom_nav); // Load the layout with the bottom nav bar

        // Connect the bottom nav view to the layout
        bottomNavigationView = findViewById(R.id.bottom_nav);

        // Set what happens when a bottom nav item is selected
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int id = item.getItemId();  // Get the ID of the clicked menu item

            // If "Account" is selected, go to the AccountInfoActivity
            if (id == R.id.nav_account) {
                startActivity(new Intent(this, AccountInfoActivity.class));
                return true;

                // If "Change Password" is selected, go to ChangePasswordActivity
            } else if (id == R.id.nav_change_password) {
                startActivity(new Intent(this, ChangePasswordActivity.class));
                return true;

                // If "Logout" is selected, go back to LoginActivity and clear the activity history
            } else if (id == R.id.nav_logout) {
                Intent intent = new Intent(this, LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // Clears back stack
                startActivity(intent);
                return true;
            }

            return false; // If none of the above matched, do nothing
        });
    }
}