package com.example.eventtracker;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    // Declare UI components and database helper
    EditText usernameField, passwordField;
    Button loginBtn, registerBtn;
    TextView forgotUsername, forgotPassword;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login); // Connects this activity to its layout XML

        // Create the database helper object
        db = new DatabaseHelper(this);

        // Link Java variables to the XML elements
        usernameField = findViewById(R.id.editUsername);
        passwordField = findViewById(R.id.editPassword);
        loginBtn = findViewById(R.id.btnLogin);
        registerBtn = findViewById(R.id.btnRegister);
        forgotUsername = findViewById(R.id.forgotUsername);
        forgotPassword = findViewById(R.id.forgotPassword);

        // When Login button is clicked
        loginBtn.setOnClickListener(v -> {
            String user = usernameField.getText().toString().trim(); // Get entered username
            String pass = passwordField.getText().toString().trim(); // Get entered password

            // Make sure both fields are filled out
            if (user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Enter username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            // Check if user exists in the database
            if (db.loginUser(user, pass)) {
                // Save the logged-in user using SharedPreferences
                SharedPreferences prefs = getSharedPreferences("EventTrackerPrefs", MODE_PRIVATE);
                SharedPreferences.Editor editor = prefs.edit();
                editor.putString("loggedInUser", user);
                editor.apply(); // Save changes

                // Show success and go to the HomeActivity screen
                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, HomeActivity.class));
                finish(); // Close login screen so user can't go back to it
            } else {
                // Show error if login fails
                Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
            }
        });

        // When Register button is clicked, go to RegisterActivity
        registerBtn.setOnClickListener(v -> {
            Intent intent = new Intent(this, RegisterActivity.class);
            startActivity(intent);
        });

        // Show alert dialog when user forgets username
        forgotUsername.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("Forgot Username")
                    .setMessage("Please contact support or check your email to retrieve your username.")
                    .setPositiveButton("OK", null)
                    .show();
        });

        // Show alert dialog when user forgets password
        forgotPassword.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("Forgot Password")
                    .setMessage("Please contact support to reset your password.")
                    .setPositiveButton("OK", null)
                    .show();
        });
    }
}