package com.example.eventtracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class EventDetailActivity extends AppCompatActivity {

    // UI elements for inputs and buttons
    EditText inputName, inputGuests, inputRoom;
    Button btnUpdate, btnDelete, btnBackEvents, btnBackHome;

    // Database helper instance
    DatabaseHelper db;

    // ID of the event being viewed or edited
    int eventId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_detail);

        // Initialize database
        db = new DatabaseHelper(this);

        // Get references to the input fields and buttons
        inputName = findViewById(R.id.inputName);
        inputGuests = findViewById(R.id.inputGuests);
        inputRoom = findViewById(R.id.inputRoom);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnDelete = findViewById(R.id.btnDelete);
        btnBackEvents = findViewById(R.id.btnBackToList);
        btnBackHome = findViewById(R.id.btnBackToHome);

        // Receive event data passed from previous screen
        Intent intent = getIntent();
        eventId = intent.getIntExtra("event_id", -1);
        String name = intent.getStringExtra("event_name");
        int value = intent.getIntExtra("event_value", -1);
        String room = intent.getStringExtra("event_room");

        // Set the received data into the input fields
        inputName.setText(name);
        inputGuests.setText(String.valueOf(value));
        inputRoom.setText(room);

        // Update button - updates event details in the database
        btnUpdate.setOnClickListener(v -> {
            String newName = inputName.getText().toString().trim();
            String newValueStr = inputGuests.getText().toString().trim();
            String newRoom = inputRoom.getText().toString().trim();

            // Check if all fields are filled
            if (!newName.isEmpty() && !newValueStr.isEmpty() && !newRoom.isEmpty()) {
                int newValue = Integer.parseInt(newValueStr);
                boolean updated = db.updateEvent(eventId, newName, newValue, newRoom);
                if (updated) {
                    Toast.makeText(this, "Event updated", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Delete button - deletes the event from the database
        btnDelete.setOnClickListener(v -> {
            boolean deleted = db.deleteEvent(eventId);
            if (deleted) {
                Toast.makeText(this, "Event deleted", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, EventListActivity.class)); // Go back to event list
                finish(); // Close this activity
            } else {
                Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show();
            }
        });

        // Button to go back to event list screen
        btnBackEvents.setOnClickListener(v -> {
            startActivity(new Intent(this, EventListActivity.class));
            finish();
        });

        // Button to go back to the home screen
        btnBackHome.setOnClickListener(v -> {
            startActivity(new Intent(this, HomeActivity.class));
            finish();
        });
    }
}