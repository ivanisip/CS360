package com.example.eventtracker;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * Small helper class to request SMS permission and send an SMS.
 * Keeps SMS logic in one place so activities can call SMSHelper.sendSMS(...)
 */
public class SMSHelper {
    // Request code used when asking the user for SMS permission
    private static final int SMS_PERMISSION_CODE = 101;

    /**
     * Send an SMS message. If the SEND_SMS permission is not granted,
     * this method will request it. If permission is already granted,
     * the text message is sent immediately.
     *
     * @param activity The calling Activity (needed to request permission)
     * @param number   Phone number to send the SMS to (as a String)
     * @param message  The SMS message body
     */
    public static void sendSMS(Activity activity, String number, String message) {
        // Check if SEND_SMS permission is granted
        if (ContextCompat.checkSelfPermission(activity, android.Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            // Permission not granted — ask the user for it.
            // The calling activity will receive the result in onRequestPermissionsResult().
            ActivityCompat.requestPermissions(activity,
                    new String[]{android.Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            // Permission already granted — send the SMS now
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(number, null, message, null, null);
        }
    }
}