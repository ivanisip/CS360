package com.example.eventtracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

// This class helps manage the app's database
public class DatabaseHelper extends SQLiteOpenHelper {

    // Database name and version
    public static final String DB_NAME = "AppDB.db";
    public static final int DB_VERSION = 7; // Increase this if you change the table structure

    // User table and its columns
    public static final String USER_TABLE = "Users";
    public static final String COL_USER_USERNAME = "username";
    public static final String COL_USER_PASSWORD = "password";
    public static final String COL_USER_FIRST = "first_name";
    public static final String COL_USER_LAST = "last_name";
    public static final String COL_USER_EMAIL = "email";

    // Event table and its columns
    public static final String EVENT_TABLE = "Events";
    public static final String COL_EVENT_ID = "id";
    public static final String COL_EVENT_NAME = "name";
    public static final String COL_EVENT_VALUE = "quantity";
    public static final String COL_EVENT_ROOM = "room";

    // Constructor to create the database
    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    // This method creates the tables when the database is first created
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + USER_TABLE + " (" +
                COL_USER_USERNAME + " TEXT PRIMARY KEY, " +
                COL_USER_PASSWORD + " TEXT, " +
                COL_USER_FIRST + " TEXT, " +
                COL_USER_LAST + " TEXT, " +
                COL_USER_EMAIL + " TEXT)");

        db.execSQL("CREATE TABLE " + EVENT_TABLE + " (" +
                COL_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_EVENT_NAME + " TEXT, " +
                COL_EVENT_VALUE + " INTEGER, " +
                COL_EVENT_ROOM + " TEXT)");
    }

    // This method is called if you change the database version
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + USER_TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + EVENT_TABLE);
        onCreate(db); // Recreate tables
    }

    // Register a new user if the username is not already taken
    public boolean registerUser(String username, String password, String firstName, String lastName, String email) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Check if the username already exists
        Cursor cursor = db.rawQuery("SELECT * FROM " + USER_TABLE + " WHERE username = ?", new String[]{username});
        if (cursor.getCount() > 0) {
            cursor.close();
            return false; // User already exists
        }

        // Add user to the database
        ContentValues values = new ContentValues();
        values.put(COL_USER_USERNAME, username);
        values.put(COL_USER_PASSWORD, password);
        values.put(COL_USER_FIRST, firstName);
        values.put(COL_USER_LAST, lastName);
        values.put(COL_USER_EMAIL, email);
        long result = db.insert(USER_TABLE, null, values);
        cursor.close();
        return result != -1;
    }

    // Login by checking username and password
    public boolean loginUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + USER_TABLE +
                " WHERE username = ? AND password = ?", new String[]{username, password});
        boolean loginSuccess = cursor.getCount() > 0;
        cursor.close();
        return loginSuccess;
    }

    // Get user info using username
    public Cursor getUserByUsername(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + USER_TABLE + " WHERE " + COL_USER_USERNAME + "=?", new String[]{username});
    }

    // Add a new event to the event table
    public boolean insertEvent(String name, int value, String room) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_EVENT_NAME, name);
        values.put(COL_EVENT_VALUE, value);
        values.put(COL_EVENT_ROOM, room);
        long result = db.insert(EVENT_TABLE, null, values);
        return result != -1;
    }

    // Get all events (used to display them in a list)
    public Cursor getAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + EVENT_TABLE, null);
    }

    // Update event information using the event's ID
    public boolean updateEvent(int id, String name, int value, String room) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_EVENT_NAME, name);
        values.put(COL_EVENT_VALUE, value);
        values.put(COL_EVENT_ROOM, room);
        int result = db.update(EVENT_TABLE, values, COL_EVENT_ID + "=?", new String[]{String.valueOf(id)});
        return result > 0;
    }

    // Delete an event using the event's ID
    public boolean deleteEvent(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(EVENT_TABLE, COL_EVENT_ID + "=?", new String[]{String.valueOf(id)});
        return result > 0;
    }

    // Another method to get user info (optional, same purpose as getUserByUsername)
    public Cursor getUserInfo(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + USER_TABLE + " WHERE username = ?", new String[]{username});
    }

    // Change the user's password
    public boolean changePassword(String username, String newPassword) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USER_PASSWORD, newPassword);
        int result = db.update(USER_TABLE, values, COL_USER_USERNAME + "=?", new String[]{username});
        return result > 0;
    }

}