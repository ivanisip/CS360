package com.example.eventtracker;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.Locale;

public class CreateEventActivity extends AppCompatActivity {

    // Declare UI components and database
    EditText editEventName, editEventValue, editEventRoom, editPhone;
    Button btnAddEvent, btnSendSMS, btnBackToHome;
    LinearLayout eventListContainer;
    DatabaseHelper db;

    // Code to identify SMS permission request
    private static final int SMS_PERMISSION_CODE = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_event); // Load the XML layout

        // Connect Java variables to layout views
        db = new DatabaseHelper(this);

        editEventName = findViewById(R.id.editEventName);
        editEventValue = findViewById(R.id.editEventValue);
        editEventRoom = findViewById(R.id.editEventRoom);
        editPhone = findViewById(R.id.editPhone);
        btnAddEvent = findViewById(R.id.btnAddEvent);
        btnSendSMS = findViewById(R.id.btnSendSMS);
        btnBackToHome = findViewById(R.id.btnBackToHome);
        eventListContainer = findViewById(R.id.eventListContainer);

        // Load existing events to show on the screen
        loadEvents();

        // Add new event to database
        btnAddEvent.setOnClickListener(v -> {
            String name = editEventName.getText().toString().trim();
            String valueStr = editEventValue.getText().toString().trim();
            String room = editEventRoom.getText().toString().trim();

            // Check if any field is empty
            if (name.isEmpty() || valueStr.isEmpty() || room.isEmpty()) {
                Toast.makeText(this, "Fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Convert guest value to number and insert into database
            int value = Integer.parseInt(valueStr);
            boolean inserted = db.insertEvent(name, value, room);

            // Show result message
            if (inserted) {
                Toast.makeText(this, "Event added", Toast.LENGTH_SHORT).show();
                editEventName.setText("");
                editEventValue.setText("");
                editEventRoom.setText("");
                loadEvents(); // Refresh the list
            } else {
                Toast.makeText(this, "Failed to add event", Toast.LENGTH_SHORT).show();
            }
        });

        // Send SMS reminder
        btnSendSMS.setOnClickListener(v -> {
            String phone = editPhone.getText().toString().trim();

            // Make sure phone number is entered
            if (phone.isEmpty()) {
                Toast.makeText(this, "Enter phone number", Toast.LENGTH_SHORT).show();
                return;
            }

            String message = "Reminder: You have events in your Event Tracker app.";

            // Ask for SMS permission if not already granted
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
            } else {
                // Send SMS
                SmsManager sms = SmsManager.getDefault();
                sms.sendTextMessage(phone, null, message, null, null);
                Toast.makeText(this, "SMS sent", Toast.LENGTH_SHORT).show();
            }
        });

        // Go back to Home screen
        btnBackToHome.setOnClickListener(v -> {
            startActivity(new Intent(this, HomeActivity.class));
            finish();
        });
    }

    // This method loads all events from the database and displays them in the list
    private void loadEvents() {
        eventListContainer.removeAllViews(); // Clear current list
        Cursor cursor = db.getAllItems(); // Get all event data

        if (cursor != null) {
            while (cursor.moveToNext()) {
                // Get event data
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_EVENT_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_EVENT_NAME));
                int value = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_EVENT_VALUE));
                String room = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_EVENT_ROOM));

                // Create a text view for each event
                TextView eventView = new TextView(this);
                eventView.setText(String.format(Locale.getDefault(), "%s (%s): %d guests", name, room, value));
                eventView.setTextSize(16);
                eventView.setPadding(0, 8, 0, 8);

                // When you click on an event, go to the event details screen
                eventView.setOnClickListener(view -> {
                    Intent intent = new Intent(this, EventDetailActivity.class);
                    intent.putExtra("event_id", id);
                    intent.putExtra("event_name", name);
                    intent.putExtra("event_value", value);
                    intent.putExtra("event_room", room);
                    startActivity(intent);
                });

                eventListContainer.addView(eventView); // Add to layout
            }
            cursor.close();
        }
    }

    // This handles the result of the SMS permission request
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            // Permission granted
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted. Try again.", Toast.LENGTH_SHORT).show();
            } else {
                // Permission denied
                Toast.makeText(this, "SMS permission denied.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}