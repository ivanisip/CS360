package com.example.eventtracker;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class HomeActivity extends AppCompatActivity {

    // This is the bottom navigation bar at the bottom of the screen
    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home); // Uses layout that includes FrameLayout and bottom_nav

        // Connect the BottomNavigationView to the one in the layout
        bottomNavigationView = findViewById(R.id.bottom_nav);

        // By default, show the HomeFragment when this screen loads
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.frame_layout, new HomeFragment()) // Puts HomeFragment inside the frame
                .commit();

        // Handle clicks on the bottom navigation items
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int id = item.getItemId();

            if (id == R.id.nav_account) {
                // Open account info screen
                startActivity(new Intent(this, AccountInfoActivity.class));
                return true;

            } else if (id == R.id.nav_change_password) {
                // Open change password screen
                startActivity(new Intent(this, ChangePasswordActivity.class));
                return true;

            } else if (id == R.id.nav_logout) {
                // Log out and go back to login screen
                Intent intent = new Intent(this, LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // Clear activity stack
                startActivity(intent);
                return true;
            }

            return false;
        });
    }
}